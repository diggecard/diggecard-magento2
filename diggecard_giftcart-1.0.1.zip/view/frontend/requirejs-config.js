var config = {
    map: {
        '*': {
            giftcardIframePostMessageListener: 'Diggecard_Giftcard/js/giftcard/iframe/postMessageListener',
        }
    }
};